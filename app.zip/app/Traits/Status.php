<?php
namespace App\Traits;

trait Status{

}
