<?php

namespace App\Services\Admin;

use App\Models\Settings;

/**
 * Class SettingsService.
 */
class SettingsService
{
    public static function storeSettings($validatedData, $id)
    {


    }
}
