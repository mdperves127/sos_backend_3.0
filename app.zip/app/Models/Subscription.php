<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Subscription extends Model
{
    use HasFactory,SoftDeletes;

    protected $guarded = [];

    protected $connection = 'mysql';

    protected $casts = [
        'card_facilities_title' => 'json',
    ];
}
