<?php

namespace App\Http\Controllers\Admin;

use {{ namespacedModel }};
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use {{ namespacedParentModel }};

class EmployeeController extends Controller
{
    /**
     * Store the newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \{{ namespacedParentModel }}  ${{ parentModelVariable }}
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request, {{ parentModel }} ${{ parentModelVariable }})
    {
        abort(404);
    }

    /**
     * Display the resource.
     *
     * @param  \{{ namespacedParentModel }}  ${{ parentModelVariable }}
     * @return \Illuminate\Http\Response
     */
    public function show({{ parentModel }} ${{ parentModelVariable }})
    {
        //
    }

    /**
     * Update the resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \{{ namespacedParentModel }}  ${{ parentModelVariable }}
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, {{ parentModel }} ${{ parentModelVariable }})
    {
        //
    }

    /**
     * Remove the resource from storage.
     *
     * @param  \{{ namespacedParentModel }}  ${{ parentModelVariable }}
     * @return \Illuminate\Http\Response
     */
    public function destroy({{ parentModel }} ${{ parentModelVariable }})
    {
        abort(404);
    }
}
