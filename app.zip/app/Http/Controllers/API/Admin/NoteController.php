<?php

namespace App\Http\Controllers\API\Admin;

use App\Http\Controllers\Controller;
use App\Models\AdminAdvertise;
use App\Models\Note;
use App\Models\PaymentHistory;
use App\Models\ServiceOrder;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class NoteController extends Controller {

    public function index() {

        return response()->json( [
            'status' => 200,
            'Note'   => Note::on('mysql')->latest()->get(),
        ] );
    }

    public function store( Request $request ) {
        $validator = Validator::make( $request->all(), [
            'note' => 'required',
        ] );
        if ( $validator->fails() ) {
            return response()->json( [
                'validation_errors' => $validator->messages(),
            ] );
        }

        Note::on('mysql')->create( [
            'tenant_id' => $request->user_id,
            'note'    => $request->note,
            'status'  => "unread",
        ] );

        return response()->json( [
            'status'  => 200,
            'message' => 'Note Added Successfully!',
        ] );
    }

    public function tenantNote( $id ) {

        $notes = Note::on('mysql')->where( 'tenant_id', $id )->paginate( 10 );

        return response()->json( [
            'status' => 200,
            'notes'  => $notes,
        ] );

    }

public function vendorAdvertise( $id ) {
        $type = request('type');

        if( $type == 'tenant' ) {
            $advertise = AdminAdvertise::where( 'tenant_id', $id )->paginate( 10 );
        } else {
            $advertise = AdminAdvertise::where( 'user_id', $id )->paginate( 10 );
        }


        return response()->json( [
            'status'    => 200,
            'advertise' => $advertise,
        ] );

    }

    public function vendorServiceOrder( $id ) {

        $type = request('type');
        if( $type == 'tenant' ) {
            $serviceOrder = ServiceOrder::where( 'tenant_id', $id )->paginate( 10 );
        } else {
            $serviceOrder = ServiceOrder::where( 'user_id', $id )->paginate( 10 );
        }


        return response()->json( [
            'status'       => 200,
            'serviceOrder' => $serviceOrder,
        ] );

    }

    public function vendorPaymentHistory( $id ) {
        $type = request( 'type' );

        $paymentHistory = PaymentHistory::on( 'mysql' )
            ->when(
                $type == 'tenant',
                function ( $query ) use ( $id ) {
                    $query->where( 'tenant_id', $id );
                },
                function ( $query ) use ( $id ) {
                    $query->where( 'user_id', $id );
                }
            )
            ->paginate( 10 );

        return response()->json( [
            'status'       => 200,
            'serviceOrder' => $paymentHistory,
        ] );

    }
}
