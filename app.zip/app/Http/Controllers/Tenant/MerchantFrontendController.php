<?php

namespace App\Http\Controllers\Tenant;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Product;
use App\Models\Category;
use App\Models\Subcategory;
use App\Models\Brand;
use App\Models\ProductDetails;
use App\Models\Tenant;
use App\Models\User;
use App\Models\MPCategory;
use App\Models\MPSubCategory;
use App\Models\MPBrand;
use Illuminate\Support\Facades\DB;
use App\Models\ServiceContent;
use App\Models\Banner;
use App\Models\CmsSetting;
use App\Models\TenantContactFormData;
use App\Models\Order;
use App\Models\Offer;
use App\Models\Color;
use App\Models\Size;
use App\Models\News;
use App\Models\NCategory;

class MerchantFrontendController extends Controller
{
    public function products(Request $request)
    {
        // Get filter parameters
        $categoryId = $request->get('category_id');
        // Handle comma-separated category IDs
        $categoryIds = $categoryId ? array_filter(array_map('trim', explode(',', $categoryId))) : [];
        $minPrice = $request->get('min_price');
        $maxPrice = $request->get('max_price');
        $colorId = $request->get('color_id');
        $sizeId = $request->get('size_id');

        if(tenant()->type == 'dropshipper') {
            // Step 1: Get all ProductDetails from current tenant's database
            $allProductDetails = ProductDetails::where('status', 1)->get();

            // Step 2: For each ProductDetails, get tenant_id and load product from that tenant's database
            $products = collect();

            foreach ( $allProductDetails as $productDetail ) {
                // Get tenant_id from ProductDetails record (this is the merchant tenant ID)
                $storedTenantId = $productDetail->tenant_id;

                if ( !$storedTenantId || !$productDetail->product_id ) {
                    continue;
                }

                // Lookup tenant from central database
                $tenant = Tenant::on( 'mysql' )->find( $storedTenantId );
                if ( !$tenant ) {
                    continue;
                }

                $connectionName = 'tenant_' . $tenant->id;
                $databaseName   = 'storebz_tenant_' . $tenant->id;

                // Configure connection to the tenant database specified by tenant_id
                config( [
                    'database.connections.' . $connectionName => [
                        'driver'   => 'mysql',
                        'host'     => config( 'database.connections.mysql.host' ),
                        'port'     => config( 'database.connections.mysql.port' ),
                        'database' => $databaseName,
                        'username' => config( 'database.connections.mysql.username' ),
                        'password' => config( 'database.connections.mysql.password' ),
                        'charset'  => 'utf8mb4',
                        'collation'=> 'utf8mb4_unicode_ci',
                        'strict'   => false,
                    ],
                ] );
                DB::purge( $connectionName );

                // Build query with filters
                $productQuery = Product::on( $connectionName )
                    ->with( 'category', 'subcategory', 'brand', 'productImage', 'productdetails', 'vendor' );

                // Apply category filter (support multiple categories)
                if ( !empty( $categoryIds ) ) {
                    $productQuery->where( function( $q ) use ( $categoryIds ) {
                        $q->whereIn( 'category_id', $categoryIds )
                          ->orWhereIn( 'market_place_category_id', $categoryIds );
                    } );
                }

                // Apply price range filter
                if ( $minPrice !== null || $maxPrice !== null ) {
                    $productQuery->where( function( $q ) use ( $minPrice, $maxPrice ) {
                        // Use discount_price if available, otherwise selling_price
                        $q->whereRaw( 'COALESCE(discount_price, selling_price) >= ?', [$minPrice ?? 0] )
                          ->whereRaw( 'COALESCE(discount_price, selling_price) <= ?', [$maxPrice ?? 999999999] );
                    } );
                }

                // Apply color filter (product_variants has product_id, color_id; colors table: colors)
                if ( $colorId ) {
                    $productQuery->whereExists( function ( $q ) use ( $colorId ) {
                        $q->select( DB::raw( 1 ) )
                            ->from( 'product_variants' )
                            ->whereColumn( 'product_variants.product_id', 'products.id' )
                            ->where( 'product_variants.color_id', (int) $colorId )
                            ->whereNull( 'product_variants.deleted_at' );
                    } );
                }

                // Apply size filter (product_variants has product_id, size_id; sizes table: sizes)
                if ( $sizeId ) {
                    $productQuery->whereExists( function ( $q ) use ( $sizeId ) {
                        $q->select( DB::raw( 1 ) )
                            ->from( 'product_variants' )
                            ->whereColumn( 'product_variants.product_id', 'products.id' )
                            ->where( 'product_variants.size_id', (int) $sizeId )
                            ->whereNull( 'product_variants.deleted_at' );
                    } );
                }

                // Load product
                try {
                    $product = $productQuery->find( $productDetail->product_id );
                } catch ( \Exception $e ) {
                    // Skip this product if there's an error
                    continue;
                }

                if ( $product ) {
                    $products->push( $product );
                }
            }

        } else {
            // Build query with filters for non-dropshippers
            $productQuery = Product::where('status', 'active')
                ->with( 'category', 'subcategory', 'brand', 'productImage', 'productdetails' );

            // Apply category filter (support multiple categories)
            if ( !empty( $categoryIds ) ) {
                $productQuery->where( function( $q ) use ( $categoryIds ) {
                    $q->whereIn( 'category_id', $categoryIds )
                      ->orWhereIn( 'market_place_category_id', $categoryIds );
                } );
            }

            // Apply price range filter
            if ( $minPrice !== null || $maxPrice !== null ) {
                $productQuery->where( function( $q ) use ( $minPrice, $maxPrice ) {
                    // Use discount_price if available, otherwise selling_price
                    $q->whereRaw( 'COALESCE(discount_price, selling_price) >= ?', [$minPrice ?? 0] )
                      ->whereRaw( 'COALESCE(discount_price, selling_price) <= ?', [$maxPrice ?? 999999999] );
                } );
            }

            // Apply color filter (product_variants has product_id, color_id; colors table: colors)
            if ( $colorId ) {
                $productQuery->whereExists( function ( $q ) use ( $colorId ) {
                    $q->select( DB::raw( 1 ) )
                        ->from( 'product_variants' )
                        ->whereColumn( 'product_variants.product_id', 'products.id' )
                        ->where( 'product_variants.color_id', (int) $colorId )
                        ->whereNull( 'product_variants.deleted_at' );
                } );
            }

            // Apply size filter (product_variants has product_id, size_id; sizes table: sizes)
            if ( $sizeId ) {
                $productQuery->whereExists( function ( $q ) use ( $sizeId ) {
                    $q->select( DB::raw( 1 ) )
                        ->from( 'product_variants' )
                        ->whereColumn( 'product_variants.product_id', 'products.id' )
                        ->where( 'product_variants.size_id', (int) $sizeId )
                        ->whereNull( 'product_variants.deleted_at' );
                } );
            }

            $products = $productQuery->get();
        }

        // Manual pagination
        $page = (int) $request->get('page', 1);
        $perPage = (int) $request->get('per_page', 10);
        $offset = ($page - 1) * $perPage;

        $total = $products->count();
        $paginatedProducts = $products->slice($offset, $perPage);
        $lastPage = (int) max(1, ceil($total / $perPage));

        // Build pagination URLs
        $path = $request->url();
        $queryParams = $request->query();
        $buildUrl = function ($pageNum) use ($path, $queryParams) {
            $queryParams['page'] = $pageNum;
            return $path . '?' . http_build_query($queryParams);
        };

        // Build links array
        $links = [];
        $links[] = [
            'url' => $page > 1 ? $buildUrl($page - 1) : null,
            'label' => '&laquo; Previous',
            'active' => false
        ];

        for ($i = 1; $i <= $lastPage; $i++) {
            $links[] = [
                'url' => $buildUrl($i),
                'label' => (string) $i,
                'active' => $i == $page
            ];
        }

        $links[] = [
            'url' => $page < $lastPage ? $buildUrl($page + 1) : null,
            'label' => 'Next &raquo;',
            'active' => false
        ];

        // Build pagination response
        $response = [
            'data' => $paginatedProducts->values(),
            'current_page' => $page,
            'per_page' => $perPage,
            'total' => $total,
            'last_page' => $lastPage,
            'from' => $total > 0 ? $offset + 1 : null,
            'to' => $total > 0 ? min($offset + $perPage, $total) : null,
            'path' => $path,
            'first_page_url' => $buildUrl(1),
            'last_page_url' => $buildUrl($lastPage),
            'prev_page_url' => $page > 1 ? $buildUrl($page - 1) : null,
            'next_page_url' => $page < $lastPage ? $buildUrl($page + 1) : null,
            'links' => $links,
        ];

        return response()->json($response);
    }
    public function product($slug)
    {
        if(tenant()->type == 'dropshipper') {
            // Step 1: Get ProductDetails from current tenant's database by ID
            $productDetail = ProductDetails::where('slug', $slug)->first();

            if ( !$productDetail ) {
                return response()->json( [
                    'status'  => 404,
                    'message' => 'Product not found',
                ] );
            }

            // Get tenant_id from ProductDetails record (this is the merchant tenant ID)
            $storedTenantId = $productDetail->tenant_id;

            if ( !$storedTenantId || !$productDetail->product_id ) {
                return response()->json( [
                    'status'  => 404,
                    'message' => 'Product tenant information not found',
                ] );
            }

            // Lookup tenant from central database
            $tenant = Tenant::on( 'mysql' )->find( $storedTenantId );
            if ( !$tenant ) {
                return response()->json( [
                    'status'  => 404,
                    'message' => 'Tenant not found',
                ] );
            }

            $connectionName = 'tenant_' . $tenant->id;
            $databaseName   = 'storebz_tenant_' . $tenant->id;

            // Configure connection to the tenant database specified by tenant_id
            config( [
                'database.connections.' . $connectionName => [
                    'driver'   => 'mysql',
                    'host'     => config( 'database.connections.mysql.host' ),
                    'port'     => config( 'database.connections.mysql.port' ),
                    'database' => $databaseName,
                    'username' => config( 'database.connections.mysql.username' ),
                    'password' => config( 'database.connections.mysql.password' ),
                    'charset'  => 'utf8mb4',
                    'collation'=> 'utf8mb4_unicode_ci',
                    'strict'   => false,
                ],
            ] );
            DB::purge( $connectionName );

            // Load product from the tenant database using product_id
            $product = Product::on( $connectionName )
                ->with( [
                    'category',
                    'subcategory',
                    'brand',
                    'productImage',
                    'productdetails',
                    'vendor',
                    'productVariant.size',
                    'productVariant.unit',
                    'productVariant.color',
                    'productVariant.product'
                ] )
                ->where('slug', $slug)->first();

            if ( !$product ) {
                return response()->json( [
                    'status'  => 404,
                    'message' => 'Product not found in tenant database',
                ] );
            }

            $related_products = Product::on( $connectionName )
                ->with( 'category', 'subcategory', 'brand', 'productImage', 'productdetails', 'vendor' )
                ->where('market_place_category_id', $product->market_place_category_id)->where('id', '!=', $product->id)->get();

            if ( !$product ) {
                return response()->json( [
                    'status'  => 404,
                    'message' => 'Product not found in tenant database',
                ] );
            }
        } else {
            $product = Product::with( [
                'category',
                'subcategory',
                'brand',
                'productImage',
                'productdetails',
                'vendor',
                'productVariant.size',
                'productVariant.unit',
                'productVariant.color',
                'productVariant.product'
            ] )->where('slug', $slug)->first();

            if ( !$product ) {
                return response()->json( [
                    'status'  => 404,
                    'message' => 'Product not found',
                ] );
            }

            $related_products = Product::with('category', 'subcategory', 'brand', 'productImage', 'productdetails', 'vendor')->where('category_id', $product->category_id)->where('id', '!=', $product->id)->get();
        }

        return response()->json([
            'product' => $product,
            'related_products' => $related_products,
        ]);
    }

    public function categories()
    {
        if (tenant()->type == 'dropshipper') {
            // Step 1: Get all ProductDetails from current tenant's database
            $allProductDetails = ProductDetails::where('status', 1)->get();

            // Step 2: Collect unique category IDs from products
            $categoryIds = collect();

            foreach ( $allProductDetails as $productDetail ) {
                // Get tenant_id from ProductDetails record (this is the merchant tenant ID)
                $storedTenantId = $productDetail->tenant_id;

                if ( !$storedTenantId || !$productDetail->product_id ) {
                    continue;
                }

                // Lookup tenant from central database
                $tenant = Tenant::on( 'mysql' )->find( $storedTenantId );
                if ( !$tenant ) {
                    continue;
                }

                $connectionName = 'tenant_' . $tenant->id;
                $databaseName   = 'storebz_tenant_' . $tenant->id;

                // Configure connection to the tenant database specified by tenant_id
                config( [
                    'database.connections.' . $connectionName => [
                        'driver'   => 'mysql',
                        'host'     => config( 'database.connections.mysql.host' ),
                        'port'     => config( 'database.connections.mysql.port' ),
                        'database' => $databaseName,
                        'username' => config( 'database.connections.mysql.username' ),
                        'password' => config( 'database.connections.mysql.password' ),
                        'charset'  => 'utf8mb4',
                        'collation'=> 'utf8mb4_unicode_ci',
                        'strict'   => false,
                    ],
                ] );
                DB::purge( $connectionName );

                // Get market_place_category_id from the product using DB facade
                $categoryId = DB::connection( $connectionName )
                    ->table( 'products' )
                    ->where( 'id', $productDetail->product_id )
                    ->value( 'market_place_category_id' );

                if ( $categoryId ) {
                    $categoryIds->push( $categoryId );
                }
            }

            // Step 3: Get unique categories from m_p_categories (mysql database)
            $uniqueCategoryIds = $categoryIds->filter()->unique()->values()->toArray();

            if ( !empty( $uniqueCategoryIds ) ) {
                // Query categories from mysql database using DB facade
                $categoryData = DB::connection( 'mysql' )
                    ->table( 'm_p_categories' )
                    ->whereIn( 'id', $uniqueCategoryIds )
                    ->whereNull( 'deleted_at' )
                    ->get();

                // Convert to MPCategory model instances
                $categories = $categoryData->map( function( $item ) {
                    $category = new MPCategory();
                    $category->setConnection('mysql');
                    $category->setRawAttributes( (array) $item );
                    $category->exists = true;
                    return $category;
                } );
            } else {
                $categories = collect();
            }
        } else {
            $categories = Category::where('status', 'active')->get();
        }

        return response()->json($categories);
    }
    public function colors()
    {
        $colors = Color::where('status', 'active')->get();

        return response()->json($colors);
    }
    public function size()
    {
        $sizes = Size::where('status', 'active')->get();

        return response()->json($sizes);
    }
    public function subcategories()
    {
        if (tenant()->type == 'dropshipper') {
            // Step 1: Get all ProductDetails from current tenant's database
            $allProductDetails = ProductDetails::where('status', 1)->get();

            // Step 2: Collect unique subcategory IDs from products
            $subcategoryIds = collect();

            foreach ( $allProductDetails as $productDetail ) {
                // Get tenant_id from ProductDetails record (this is the merchant tenant ID)
                $storedTenantId = $productDetail->tenant_id;

                if ( !$storedTenantId || !$productDetail->product_id ) {
                    continue;
                }

                // Lookup tenant from central database
                $tenant = Tenant::on( 'mysql' )->find( $storedTenantId );
                if ( !$tenant ) {
                    continue;
                }

                $connectionName = 'tenant_' . $tenant->id;
                $databaseName   = 'storebz_tenant_' . $tenant->id;

                // Configure connection to the tenant database specified by tenant_id
                config( [
                    'database.connections.' . $connectionName => [
                        'driver'   => 'mysql',
                        'host'     => config( 'database.connections.mysql.host' ),
                        'port'     => config( 'database.connections.mysql.port' ),
                        'database' => $databaseName,
                        'username' => config( 'database.connections.mysql.username' ),
                        'password' => config( 'database.connections.mysql.password' ),
                        'charset'  => 'utf8mb4',
                        'collation'=> 'utf8mb4_unicode_ci',
                        'strict'   => false,
                    ],
                ] );
                DB::purge( $connectionName );

                // Get market_place_subcategory_id from the product using DB facade
                $subcategoryId = DB::connection( $connectionName )
                    ->table( 'products' )
                    ->where( 'id', $productDetail->product_id )
                    ->value( 'market_place_subcategory_id' );

                if ( $subcategoryId ) {
                    $subcategoryIds->push( $subcategoryId );
                }
            }

            // Step 3: Get unique subcategories from m_p_sub_categories (mysql database)
            $uniqueSubcategoryIds = $subcategoryIds->filter()->unique()->values()->toArray();

            if ( !empty( $uniqueSubcategoryIds ) ) {
                // Query subcategories from mysql database using DB facade
                $subcategoryData = DB::connection( 'mysql' )
                    ->table( 'm_p_sub_categories' )
                    ->whereIn( 'id', $uniqueSubcategoryIds )
                    ->whereNull( 'deleted_at' )
                    ->get();

                // Convert to MPSubCategory model instances
                $subcategories = $subcategoryData->map( function( $item ) {
                    $subcategory = new MPSubCategory();
                    $subcategory->setConnection('mysql');
                    $subcategory->setRawAttributes( (array) $item );
                    $subcategory->exists = true;
                    return $subcategory;
                } );
            } else {
                $subcategories = collect();
            }
        } else {
            $subcategories = Subcategory::all();
        }

        return response()->json($subcategories);
    }
    public function brands()
    {
        if (tenant()->type == 'dropshipper') {
            // Step 1: Get all ProductDetails from current tenant's database
            $allProductDetails = ProductDetails::where('status', 1)->get();

            // Step 2: Collect unique brand IDs from products
            $brandIds = collect();

            foreach ( $allProductDetails as $productDetail ) {
                // Get tenant_id from ProductDetails record (this is the merchant tenant ID)
                $storedTenantId = $productDetail->tenant_id;

                if ( !$storedTenantId || !$productDetail->product_id ) {
                    continue;
                }

                // Lookup tenant from central database
                $tenant = Tenant::on( 'mysql' )->find( $storedTenantId );
                if ( !$tenant ) {
                    continue;
                }

                $connectionName = 'tenant_' . $tenant->id;
                $databaseName   = 'storebz_tenant_' . $tenant->id;

                // Configure connection to the tenant database specified by tenant_id
                config( [
                    'database.connections.' . $connectionName => [
                        'driver'   => 'mysql',
                        'host'     => config( 'database.connections.mysql.host' ),
                        'port'     => config( 'database.connections.mysql.port' ),
                        'database' => $databaseName,
                        'username' => config( 'database.connections.mysql.username' ),
                        'password' => config( 'database.connections.mysql.password' ),
                        'charset'  => 'utf8mb4',
                        'collation'=> 'utf8mb4_unicode_ci',
                        'strict'   => false,
                    ],
                ] );
                DB::purge( $connectionName );

                // Get market_place_brand_id from the product using DB facade
                $brandId = DB::connection( $connectionName )
                    ->table( 'products' )
                    ->where( 'id', $productDetail->product_id )
                    ->value( 'market_place_brand_id' );

                if ( $brandId ) {
                    $brandIds->push( $brandId );
                }
            }

            // Step 3: Get unique brands from m_p_brands (mysql database)
            $uniqueBrandIds = $brandIds->filter()->unique()->values()->toArray();

            if ( !empty( $uniqueBrandIds ) ) {
                // Query brands from mysql database using DB facade
                $brandData = DB::connection( 'mysql' )
                    ->table( 'm_p_brands' )
                    ->whereIn( 'id', $uniqueBrandIds )
                    ->whereNull( 'deleted_at' )
                    ->get();

                // Convert to MPBrand model instances
                $brands = $brandData->map( function( $item ) {
                    $brand = new MPBrand();
                    $brand->setConnection('mysql');
                    $brand->setRawAttributes( (array) $item );
                    $brand->exists = true;
                    return $brand;
                } );
            } else {
                $brands = collect();
            }
        } else {
            $brands = Brand::all();
        }

        return response()->json($brands);
    }

    public function cmsFront()
    {
        $contentServices = ServiceContent::orderBy('order', 'asc')->get();
        $banners = Banner::orderBy('order', 'asc')->get();
        $offers = Offer::latest()->get();
        $cms = CmsSetting::first();

        // Use null-safe operator to prevent errors when $cms is null
        $populer_section_category_id_1 = $cms ? Category::find($cms->populer_section_category_id_1) : null;
        $populer_section_category_id_2 = $cms ? Category::find($cms->populer_section_category_id_2) : null;
        $populer_section_category_id_3 = $cms ? Category::find($cms->populer_section_category_id_3) : null;
        $populer_section_category_id_4 = $cms ? Category::find($cms->populer_section_category_id_4) : null;
        $populer_section_subcategory_id_1 = $cms ? Subcategory::find($cms->populer_section_subcategory_id_1) : null;
        $populer_section_subcategory_id_2 = $cms ? Subcategory::find($cms->populer_section_subcategory_id_2) : null;
        $populer_section_subcategory_id_3 = $cms ? Subcategory::find($cms->populer_section_subcategory_id_3) : null;
        $populer_section_subcategory_id_4 = $cms ? Subcategory::find($cms->populer_section_subcategory_id_4) : null;

        $recomended_category_id_1 = $cms ? Category::find($cms->recomended_category_id_1) : null;
        $recomended_category_id_2 = $cms ? Category::find($cms->recomended_category_id_2) : null;
        $recomended_category_id_3 = $cms ? Category::find($cms->recomended_category_id_3) : null;
        $recomended_category_id_4 = $cms ? Category::find($cms->recomended_category_id_4) : null;
        $recomended_sub_category_id_1 = $cms ? Subcategory::find($cms->recomended_sub_category_id_1) : null;
        $recomended_sub_category_id_2 = $cms ? Subcategory::find($cms->recomended_sub_category_id_2) : null;
        $recomended_sub_category_id_3 = $cms ? Subcategory::find($cms->recomended_sub_category_id_3) : null;
        $recomended_sub_category_id_4 = $cms ? Subcategory::find($cms->recomended_sub_category_id_4) : null;

        $best_setting_category_id_1 = $cms ? Category::find($cms->best_setting_category_id_1) : null;
        $best_setting_category_id_2 = $cms ? Category::find($cms->best_setting_category_id_2) : null;
        $best_setting_category_id_3 = $cms ? Category::find($cms->best_setting_category_id_3) : null;
        $best_setting_category_id_4 = $cms ? Category::find($cms->best_setting_category_id_4) : null;
        $best_setting_sub_category_id_1 = $cms ? Subcategory::find($cms->best_setting_sub_category_id_1) : null;
        $best_setting_sub_category_id_2 = $cms ? Subcategory::find($cms->best_setting_sub_category_id_2) : null;
        $best_setting_sub_category_id_3 = $cms ? Subcategory::find($cms->best_setting_sub_category_id_3) : null;
        $best_setting_sub_category_id_4 = $cms ? Subcategory::find($cms->best_setting_sub_category_id_4) : null;
        $best_category_id = $cms ? Category::find($cms->best_category_id) : null;
        $best_sub_category_id = $cms ? Subcategory::find($cms->best_sub_category_id) : null;
        return response()->json([
            'content_services' => $contentServices,
            'banners' => $banners,
            'cms' => $cms,
            'offers' => $offers,
            'populer_section_category_id_1' => $populer_section_category_id_1,
            'populer_section_category_id_2' => $populer_section_category_id_2,
            'populer_section_category_id_3' => $populer_section_category_id_3,
            'populer_section_category_id_4' => $populer_section_category_id_4,
            'populer_section_subcategory_id_1' => $populer_section_subcategory_id_1,
            'populer_section_subcategory_id_2' => $populer_section_subcategory_id_2,
            'populer_section_subcategory_id_3' => $populer_section_subcategory_id_3,
            'populer_section_subcategory_id_4' => $populer_section_subcategory_id_4,
            'recomended_category_id_1' => $recomended_category_id_1,
            'recomended_category_id_2' => $recomended_category_id_2,
            'recomended_category_id_3' => $recomended_category_id_3,
            'recomended_category_id_4' => $recomended_category_id_4,
            'recomended_sub_category_id_1' => $recomended_sub_category_id_1,
            'recomended_sub_category_id_2' => $recomended_sub_category_id_2,
            'recomended_sub_category_id_3' => $recomended_sub_category_id_3,
            'recomended_sub_category_id_4' => $recomended_sub_category_id_4,
            'best_setting_category_id_1' => $best_setting_category_id_1,
            'best_setting_category_id_2' => $best_setting_category_id_2,
            'best_setting_category_id_3' => $best_setting_category_id_3,
            'best_setting_category_id_4' => $best_setting_category_id_4,
            'best_setting_sub_category_id_1' => $best_setting_sub_category_id_1,
            'best_setting_sub_category_id_2' => $best_setting_sub_category_id_2,
            'best_setting_sub_category_id_3' => $best_setting_sub_category_id_3,
            'best_setting_sub_category_id_4' => $best_setting_sub_category_id_4,
            'best_category_id' => $best_category_id,
            'best_sub_category_id' => $best_sub_category_id,
        ]);
    }

    public function productsFilter($sub_category_id) {
        if ($sub_category_id != null) {
            $products = Product::where('subcategory_id', $sub_category_id)->get();
        }

        return response()->json($products);
    }

    public function searchItem(Request $request, $search, $category_id = null) {
        // category_id from route (search/item/term/2) or query string (?category_id=2)
        $category_id = $category_id ?? $request->query('category_id');

        $query = Product::where('name', 'like', '%' . $search . '%');

        if ($category_id !== null && $category_id !== '' && (int) $category_id > 0) {
            $query->where('category_id', (int) $category_id);
        }

        $products = $query->get();
        return response()->json($products);
    }

    public function orders() {
        $orders = Order::where('vendor_id', auth()->user()->id)->where('tenant_id', tenant()->id)->get();
        $all_order = $orders->count();
        $pending_order = $orders->where('status', 'pending')->count();
        $processing_order = $orders->where('status', 'processing')->count();
        $completed_order = $orders->where('status', 'completed')->count();
        $cancelled_order = $orders->where('status', 'cancelled')->count();
        return response()->json([
            'orders' => $orders,
            'all_order' => $all_order,
            'pending_order' => $pending_order,
            'processing_order' => $processing_order,
            'completed_order' => $completed_order,
            'cancelled_order' => $cancelled_order
        ]);
    }

    public function contact(Request $request) {
        $contact = new TenantContactFormData();
        $contact->name = $request->name;
        $contact->email = $request->email;
        $contact->subject = $request->subject;
        $contact->message = $request->message;
        $contact->save();
        return response()->json($contact);
    }
    public function newsFront()
    {
        $news = News::with('nCategory')->get();
        return response()->json([
            'status' => 200,
            'news' => $news,
        ]);
    }
    public function newsDetail($slug)
    {
        $news = News::with('nCategory')->where('slug', $slug)->first();
        return response()->json([
            'status' => 200,
            'news' => $news,
        ]);
    }
    public function newsCategory()
    {
        $categories = NCategory::all();
        return response()->json([
            'status' => 200,
            'categories' => $categories,
        ]);
    }
}
