<?php

namespace App\Http\Controllers\Tenant;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\CmsSetting;

class CmsController extends Controller
{
    public function index()
    {
        $data = CmsSetting::first();
        return response()->json([
            'status' => true,
            'data' => $data
        ]);
    }

    public function update(Request $request)
    {
        $data = CmsSetting::first();

        if ($request->hasFile('logo')) {
            $file = $request->file('logo');
            $extension = $file->getClientOriginalExtension();
            $filename = time() . '.' . $extension;
            $file->move('uploads/logo/', $filename);
            $data->logo = 'uploads/logo/' . $filename;
        }
        if($request->hasFile('footer_logo')){
            $file = $request->file('footer_logo');
            $extension = $file->getClientOriginalExtension();
            $filename = time() . '.' . $extension;
            $file->move('uploads/footer-logo/', $filename);
            $data->footer_logo = 'uploads/footer-logo/' . $filename;
        }

        if($request->hasFile('populer_section_banner')){
            $file = $request->file('populer_section_banner');
            $extension = $file->getClientOriginalExtension();
            $filename = time() . '.' . $extension;
            $file->move('uploads/populer-section-banner/', $filename);
            $data->populer_section_banner = 'uploads/populer-section-banner/' . $filename;
        }

        if ($request->hasFile('banner_1')) {
            $file = $request->file('banner_1');
            $extension = $file->getClientOriginalExtension();
            $filename = time() . '.' . $extension;
            $file->move('uploads/banner-1/', $filename);
            $data->banner_1 = 'uploads/banner-1/' . $filename;
        }
        if ($request->hasFile('banner_2')) {
            $file = $request->file('banner_2');
            $extension = $file->getClientOriginalExtension();
            $filename = time() . '.' . $extension;
            $file->move('uploads/banner-2/', $filename);
            $data->banner_2 = 'uploads/banner-2/' . $filename;
        }
        if ($request->hasFile('banner_3')) {
            $file = $request->file('banner_3');
            $extension = $file->getClientOriginalExtension();
            $filename = time() . '.' . $extension;
            $file->move('uploads/banner-3/', $filename);
            $data->banner_3 = 'uploads/banner-3/' . $filename;
        }

        if ($request->hasFile('three_column_banner_1')) {
            $file = $request->file('three_column_banner_1');
            $extension = $file->getClientOriginalExtension();
            $filename = time() . '.' . $extension;
            $file->move('uploads/three-column-banner-1/', $filename);
            $data->three_column_banner_1 = 'uploads/three-column-banner-1/' . $filename;
        }
        if ($request->hasFile('three_column_banner_2')) {
            $file = $request->file('three_column_banner_2');
            $extension = $file->getClientOriginalExtension();
            $filename = time() . '.' . $extension;
            $file->move('uploads/three-column-banner-2/', $filename);
            $data->three_column_banner_2 = 'uploads/three-column-banner-2/' . $filename;
        }
        if ($request->hasFile('three_column_banner_3')) {
            $file = $request->file('three_column_banner_3');
            $extension = $file->getClientOriginalExtension();
            $filename = time() . '.' . $extension;
            $file->move('uploads/three-column-banner-3/', $filename);
            $data->three_column_banner_3 = 'uploads/three-column-banner-3/' . $filename;
        }

        if ($request->hasFile('two_column_banner_1')) {
            $file = $request->file('two_column_banner_1');
            $extension = $file->getClientOriginalExtension();
            $filename = time() . '.' . $extension;
            $file->move('uploads/two-column-banner-1/', $filename);
            $data->two_column_banner_1 = 'uploads/two-column-banner-1/' . $filename;
        }
        if ($request->hasFile('two_column_banner_2')) {
            $file = $request->file('two_column_banner_2');
            $extension = $file->getClientOriginalExtension();
            $filename = time() . '.' . $extension;
            $file->move('uploads/two-column-banner-2/', $filename);
            $data->two_column_banner_2 = 'uploads/two-column-banner-2/' . $filename;
        }
        if ($request->hasFile('footer_payment_methods')) {
            $file = $request->file('footer_payment_methods');
            $extension = $file->getClientOriginalExtension();
            $filename = time() . '.' . $extension;
            $file->move('uploads/footer-payment-methods/', $filename);
            $data->footer_payment_methods = 'uploads/footer-payment-methods/' . $filename;
        }
        if ($request->hasFile('fav_icon')) {
            $file = $request->file('fav_icon');
            $extension = $file->getClientOriginalExtension();
            $filename = time() . '.' . $extension;
            $file->move('uploads/fav-icon/', $filename);
            $data->fav_icon = 'uploads/fav-icon/' . $filename;
        }
        if ($request->hasFile('auth_page_image')) {
            $file = $request->file('auth_page_image');
            $extension = $file->getClientOriginalExtension();
            $filename = time() . '.' . $extension;
            $file->move('uploads/auth-page-image/', $filename);
            $data->auth_page_image = 'uploads/auth-page-image/' . $filename;
        }

        if ($request->hasFile('f_banner_group_title_image')) {
            $file = $request->file('f_banner_group_title_image ');
            $extension = $file->getClientOriginalExtension();
            $filename = time() . '.' . $extension;
            $file->move('uploads/f_banner_group_title_image /', $filename);
            $data->f_banner_group_title_image  = 'uploads/f_banner_group_title_image/' . $filename;
        }
        if ($request->hasFile('f_banner_image_1')) {
            $file = $request->file('f_banner_image_1');
            $extension = $file->getClientOriginalExtension();
            $filename = time() . '.' . $extension;
            $file->move('uploads/f_banner_image_1/', $filename);
            $data->f_banner_image_1   = 'uploads/f_banner_image_1/' . $filename;
        }
        if ($request->hasFile('f_banner_image_2')) {
            $file = $request->file('f_banner_image_2');
            $extension = $file->getClientOriginalExtension();
            $filename = time() . '.' . $extension;
            $file->move('uploads/f_banner_image_2/', $filename);
            $data->f_banner_image_2   = 'uploads/f_banner_image_2/' . $filename;
        }
        if ($request->hasFile('f_banner_image_3')) {
            $file = $request->file('f_banner_image_3');
            $extension = $file->getClientOriginalExtension();
            $filename = time() . '.' . $extension;
            $file->move('uploads/f_banner_image_3/', $filename);
            $data->f_banner_image_3   = 'uploads/f_banner_image_3/' . $filename;
        }
        if ($request->hasFile('f_feature_image_4')) {
            $file = $request->file('f_feature_image_4');
            $extension = $file->getClientOriginalExtension();
            $filename = time() . '.' . $extension;
            $file->move('uploads/f_feature_image_4/', $filename);
            $data->f_feature_image_4   = 'uploads/f_feature_image_4/' . $filename;
        }
        if ($request->hasFile('f_feature_image_5')) {
            $file = $request->file('f_feature_image_5');
            $extension = $file->getClientOriginalExtension();
            $filename = time() . '.' . $extension;
            $file->move('uploads/f_feature_image_5/', $filename);
            $data->f_feature_image_5   = 'uploads/f_feature_image_5/' . $filename;
        }
        if ($request->hasFile('f_feature_image_6')) {
            $file = $request->file('f_feature_image_6');
            $extension = $file->getClientOriginalExtension();
            $filename = time() . '.' . $extension;
            $file->move('uploads/f_feature_image_6/', $filename);
            $data->f_feature_image_6   = 'uploads/f_feature_image_6/' . $filename;
        }
        if ($request->hasFile('f_feature_image_8')) {
            $file = $request->file('f_feature_image_8');
            $extension = $file->getClientOriginalExtension();
            $filename = time() . '.' . $extension;
            $file->move('uploads/f_feature_image_8/', $filename);
            $data->f_feature_image_8   = 'uploads/f_feature_image_8/' . $filename;
        }
        $data->fill($request->except([
            'logo',
            'footer_logo',
            'populer_section_banner',
            'banner_1',
            'banner_2',
            'banner_3',
            'three_column_banner_1',
            'three_column_banner_2',
            'three_column_banner_3',
            'two_column_banner_1',
            'two_column_banner_2',
            'footer_payment_methods',
            'fav_icon',
            'auth_page_image',
            'f_banner_group_title_image',
            'f_banner_image_1',
            'f_banner_image_2',
            'f_banner_image_3',
            'f_feature_image_4',
            'f_feature_image_5',
            'f_feature_image_6',
            'f_feature_image_8'

        ]));
        $data->save();

        return response()->json([
            'status' => true,
            'message' => 'Cms Setting Updated Successfully',
            'data' => $data
        ]);
    }
}
